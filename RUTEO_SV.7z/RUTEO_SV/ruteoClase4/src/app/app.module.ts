import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppComponent } from './app.component';
import { AlumnosComponent } from './componentes/alumnos/alumnos.component';
import { GrillaComponent } from './componentes/grilla/grilla.component';
import { ErrorComponent } from './componentes/error/error.component';
import { LoginComponent } from './componentes/login/login.component';
import { DatosComponent } from './componentes/datos/datos.component';
import { NgModel } from '@angular/forms';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RuteandoModule } from './ruteando.module';

@NgModule({
  declarations: [
    AppComponent,
    AlumnosComponent,
    GrillaComponent,
    ErrorComponent,
    LoginComponent,
    DatosComponent
    
  ],
  imports: [
    BrowserModule,
    RuteandoModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
