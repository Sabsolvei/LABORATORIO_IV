import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './componentes/login/login.component';
import { AlumnosComponent } from './componentes/alumnos/alumnos.component';
import { DatosComponent } from './componentes/datos/datos.component';
import { GrillaComponent } from './componentes/grilla/grilla.component';
import { ErrorComponent } from './componentes/error/error.component';


const MiRuteo = [
{path: '' , component: LoginComponent},
{path: 'Login' , component: LoginComponent},
{ path: 'Alumnos' ,
component: AlumnosComponent ,
children:
     [{path: 'Grilla' , component: GrillaComponent},
     {path: 'Datos' , component: DatosComponent}    
    ]
},
{path: '**' , component: ErrorComponent},
{path: 'error' , component: ErrorComponent}];

@NgModule({
  imports: [
    RouterModule.forRoot(MiRuteo)
  ],
  exports: [
    RouterModule
  ]
})
export class RuteandoModule { }
