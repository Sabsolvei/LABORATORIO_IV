import { Component, OnInit, Input, Output, EventEmitter, Inject, ViewChild } from '@angular/core';

@Component({
  selector: 'app-datos',
  templateUrl: './datos.component.html',
  styleUrls: ['./datos.component.css']
})
export class DatosComponent implements OnInit {
  @Output() enviarDatos: EventEmitter<any> = new EventEmitter<any>();
  constructor() { }

  enviarResultados() {
    this.enviarDatos.emit("Datitos");
  }
  ngOnInit() {
  }

}
