import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
@Component({
  selector: 'app-alumnos',
  templateUrl: './alumnos.component.html',
  styleUrls: ['./alumnos.component.css']
})
export class AlumnosComponent implements OnInit {

  constructor(private route: ActivatedRoute,
    private router: Router) { }
public datos:string;
  ngOnInit() {
  }

  Redireccionar()
  {
    this.router.navigate(['Alumnos/Datos']);
  }

  RedireccionarGrilla()
  {
    this.router.navigate(['Alumnos/Grilla']);
  }
  GuardarDatos(datos: string) {
    this.datos = datos;
    console.log(datos);
  }
}
