import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pag-paises',
  templateUrl: './pag-paises.component.html',
  styleUrls: ['./pag-paises.component.css']
})
export class PagPaisesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
