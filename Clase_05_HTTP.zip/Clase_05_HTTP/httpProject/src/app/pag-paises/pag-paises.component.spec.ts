import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PagPaisesComponent } from './pag-paises.component';

describe('PagPaisesComponent', () => {
  let component: PagPaisesComponent;
  let fixture: ComponentFixture<PagPaisesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PagPaisesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PagPaisesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
