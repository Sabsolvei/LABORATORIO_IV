import { Component } from '@angular/core';
import { PaisesService } from './services/paises.service';
import { } from './lista-paises/lista-paises.component';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent {
  title = 'app';

  public nombrePais: string;
  public dataPaises;
  public dataPaisesPorNombre;


  constructor(public pService: PaisesService) {
  }

  enviarPaises() {
    this.pService.listar()
      .then(datos => {
        console.info("listado de paises", datos);
        this.dataPaises = datos;
      });
  }

  enviarPPorNombre(np: string) {
    this.pService.listarNombre(np)
    .then(datos => {
      console.info("listado de paises por nombre", datos);
      this.dataPaises = datos;
    });
  }

}