import { Component, OnInit, Input } from '@angular/core';
import { PaisesService } from '../services/paises.service'
@Component({
  selector: 'app-lista-paises',
  templateUrl: './lista-paises.component.html',
  styleUrls: ['./lista-paises.component.css']
})
export class ListaPaisesComponent implements OnInit {
  @Input() listadoDePaises;

  constructor() {
    
   }

  ngOnInit() {
    // this.miServicioDePaises.listar()
    // .then(datos=>{
    //   console.info("listado de paises",datos);
    //   this.listadoPaises=datos;
    // });
  }

}
