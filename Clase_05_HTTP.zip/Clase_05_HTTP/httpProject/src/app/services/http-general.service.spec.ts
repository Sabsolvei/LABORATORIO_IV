import { TestBed, inject } from '@angular/core/testing';

import { HttpGeneralService } from './http-general.service';

describe('HttpGeneralService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [HttpGeneralService]
    });
  });

  it('should be created', inject([HttpGeneralService], (service: HttpGeneralService) => {
    expect(service).toBeTruthy();
  }));
});
