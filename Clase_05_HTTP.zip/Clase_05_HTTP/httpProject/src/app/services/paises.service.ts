import { Injectable } from '@angular/core';
import { HttpGeneralService } from './http-general.service';

@Injectable()
export class PaisesService {
  public listapaises;
  constructor(public miHttp: HttpGeneralService) { }


  public listar(): Promise<Array<any>> {
    return this.miHttp.httpGetP("all")
      .then(data => {
        console.log(data);
        return data;
      })
      .catch(err => {
        console.log(err);
        return null;
      });
    //return null;
  }

  public listarNombre(nombrePais: any): Promise<Array<any>> {
    return this.miHttp.httpGetP("all").then(data => {
      console.info("jugadores service", data);
      this.listapaises = data;
      let ganador: boolean;
      this.listapaises = this.listapaises.filter(
        data => data.name === nombrePais); return this.listapaises
    }
    )
      .catch(errror => {
        console.log("error");
        return this.listapaises;

      });
  }
}
