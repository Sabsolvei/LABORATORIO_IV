import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { NgModel } from '@angular/forms';
import { AppComponent } from './app.component';
import { PagPaisesComponent } from './pag-paises/pag-paises.component';
import { ListaPaisesComponent } from './lista-paises/lista-paises.component';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { HttpGeneralService } from './services/http-general.service';
import { PaisesService } from './services/paises.service';

@NgModule({
  declarations: [
    AppComponent,
    PagPaisesComponent,
    ListaPaisesComponent,
    
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule
  ],
  providers: [ PaisesService, HttpGeneralService],
  bootstrap: [AppComponent]
})
export class AppModule { }
