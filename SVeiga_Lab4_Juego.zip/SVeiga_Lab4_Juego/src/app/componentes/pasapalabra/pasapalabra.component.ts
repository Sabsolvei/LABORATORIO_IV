import { Component, OnInit, Input, Output, EventEmitter, Inject, ViewChild } from '@angular/core';
import { Subscription } from "rxjs";
import { Router, ActivatedRoute, ParamMap, NavigationEnd } from '@angular/router';
import { TimerObservable } from "rxjs/observable/TimerObservable";
import { JuegoPasapalabra } from '../../clases/juego-pasapalabra';

import { MatDialog, MatDialogRef, MAT_DIALOG_DATA, MatDialogClose, MatDialogActions, MatDialogConfig } from '@angular/material';
import { ModalPasapalabraComponent } from '../modal-pasapalabra/modal-pasapalabra.component';

import { DomSanitizer } from '@angular/platform-browser';
import { FormGroup } from '@angular/forms';

@Component({
  selector: 'app-pasapalabra',
  templateUrl: './pasapalabra.component.html',
  styleUrls: ['./pasapalabra.component.css']
})


export class PasapalabraComponent implements OnInit {
  @ViewChild('openModal') openModal: ModalPasapalabraComponent;
  @Output() enviarJuego: EventEmitter<any> = new EventEmitter<any>();

  public modal;

  nuevoJuego: JuegoPasapalabra;
  tiempo: number;
  repetidor: any;
  private subscription: Subscription;
  public abc = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'Z', 'I', 'Y', 'J', 'X', 'K', 'W', 'L', 'V', 'M', 'U', 'T', 'S', 'R', 'Q', 'P', 'O', 'N'];

  ngOnInit() {
    setTimeout(() => {  //The setTimeout() method calls a function or evaluates an expression after a specified number of milliseconds.
      this.openDialog();
    }, 1)
  }
  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private sanitizer: DomSanitizer,
    public dialog: MatDialog
  ) {
    this.tiempo = -1;
    this.nuevoJuego = new JuegoPasapalabra();
    this.modal = 1;
  }

  enviarResultados() {
    this.enviarJuego.emit(this.nuevoJuego);
  }

  NuevoJuego() {
    this.modal = 1;
    this.nuevoJuego = new JuegoPasapalabra();
    this.tiempo = 200;
    this.repetidor = setInterval(() => {

      this.tiempo--;
      if (this.tiempo == 0) {
        clearInterval(this.repetidor);
      }
    }, 900);
    this.generarDefinicion();
  }


  avanzarAbecedario() {
    this.nuevoJuego.avanzarABC();
  }

  generarDefinicion() {
    this.nuevoJuego.generarDefinicionRandom();
  }

  finalizarJuego() {

    this.nuevoJuego.contabilizarResultado();
    this.enviarResultados();
    this.openDialog();
  }

  verificar() {

    if (this.nuevoJuego.Verificar() != -1) {
      if (this.nuevoJuego.letra == 'Z') {
        this.modal = 2;
      }
      if (this.modal == 2) {
        this.finalizarJuego();
      } else {
        this.avanzarAbecedario();
        this.generarDefinicion();
      }
    }
  }



  pasapalabra() {
    this.nuevoJuego.pasapalabra();
    if (this.nuevoJuego.letra == 'Z') {
      this.modal = 2;
    }
    if (this.modal == 2) {
      this.finalizarJuego();
    } else {
      this.avanzarAbecedario();
      this.generarDefinicion();
    }
  }

  openDialog() {

    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.closeOnNavigation = true;
    dialogConfig.autoFocus = true;
    // dialogConfig.hasBackdrop = true;
    // dialogConfig.backdropClass = 'backdropC';
    dialogConfig.panelClass = 'custom-dialog';
    if (this.modal == 2) {
      dialogConfig.data = {
        respuestasCorrectas: this.nuevoJuego.cantidadCorrectas,
        respuestasIncorrectas: this.nuevoJuego.cantidadIncorrectas,
        pasapalabras: this.nuevoJuego.cantidadPasapalabra,
        modal: this.modal
      }
    } else {
      dialogConfig.data = {
        modal: this.modal
      }
    }
    dialogConfig.position = {
      top: '',
      bottom: '',
      left: '',
      right: '',
    };

    let dialogRef = this.dialog.open(
      ModalPasapalabraComponent,
      dialogConfig);

    dialogRef.afterClosed().subscribe(result => {

      if (result == "jugarotravez") {
        this.NuevoJuego();
      }
      else if (result == "jugar") {
        this.NuevoJuego();
        this.generarDefinicion();
      }
      else {
        console.log('The dialog was closed');
      }
    });
  }



  getClass(letra: string): string | any {
    let estado = this.nuevoJuego.obtengoEstado(letra)
    let clases = [];
    if (this.nuevoJuego.letra == letra && estado == 0) {
      clases.push("mat-elevation-z10");
    }
    if (this.nuevoJuego.letra != letra) {

      switch (estado) {
        case 0:
          clases.push("mat-elevation-z0", "aunNoJugoClass");

          break;

        case 1:
          clases.push("mat-elevation-z0", "correctoClass");
          break;

        case 2:
          clases.push("mat-elevation-z0", "errorClass");
          break;

        case 3:
          clases.push("mat-elevation-z0", "pasapalabraClass");
          break;
      }
      //return this.sanitizer.bypassSecurityTrustStyle(estilo);
    }
    return clases;
  }

  public obtenerEstado(letra: string) {
    return this.nuevoJuego.obtenerListaEstados(letra);
  }
}