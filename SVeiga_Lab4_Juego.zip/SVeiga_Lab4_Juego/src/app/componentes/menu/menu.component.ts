import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css']
})
export class MenuComponent implements OnInit {

  public listaJuegos;

  constructor(private route: ActivatedRoute,
    private router: Router) {
    this.listaJuegos = ["Tateti", "Pasapalabra", "Anagrama", "Piedra Papel o Tijera", "Adivina El Número", "Agilidad Aritmética"];
  }

  ngOnInit() {
  }

  Juego(tipo: string) {
    switch (tipo) {
      case 'Adivina El Número':
        this.router.navigate(['/Juegos/Adivina']);
        break;
      case 'Agilidad Aritmética':
        this.router.navigate(['/Juegos/Agilidad']);
        break;
      case 'Piedra Papel o Tijera':
        this.router.navigate(['/Juegos/PiedraPapelTijera']);
        break;
      case 'Tateti':
        this.router.navigate(['/Juegos/Tateti']);
        break;
      case 'Pasapalabra':
        this.router.navigate(['/Juegos/Pasapalabra']);
        break;
      case 'AdivinaMasListado':
        this.router.navigate(['/Juegos/AdivinaMasListado']);
        break;
      case 'AgilidadaMasListado':
        this.router.navigate(['/Juegos/AgilidadaMasListado']);
        break;
        case 'listado':
        this.router.navigate(['/Listado']);
        break;
    }
  }

}
