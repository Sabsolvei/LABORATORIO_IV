import { Component, Inject, Output, EventEmitter } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA, MatDialogClose, MatDialogActions } from '@angular/material';

/**
 * @title Dialog Overview
 */


@Component({
  selector: 'tag-modal-pasapalabra',
  templateUrl: 'modal-pasapalabra.component.html',
  styleUrls: ['./modal-pasapalabra.component.css']
})
export class ModalPasapalabraComponent {
  @Output() ejecutarNuevoJuego: EventEmitter<any> = new EventEmitter<any>();
  constructor(
    @Inject(MAT_DIALOG_DATA) private data: { respuestasCorrectas: Number, respuestasIncorrectas: Number, pasapalabras: Number, modal: Number },
    public dialogRef: MatDialogRef<ModalPasapalabraComponent>
  ) { }

  onCloseConfirm(){
    this.dialogRef.close('jugar');
    
  }

  onCloseJugarOtraVez(){
    this.dialogRef.close('jugarotravez');
  }

  onCloseCancel(): void {
    this.dialogRef.close('cancel');
  }


  empezarNuevoJuego() {
    this.ejecutarNuevoJuego.emit(1);
  }

  

}