import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ModalPasapalabraComponent } from './modal-pasapalabra.component';

describe('ModalPasapalabraComponent', () => {
  let component: ModalPasapalabraComponent;
  let fixture: ComponentFixture<ModalPasapalabraComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ModalPasapalabraComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ModalPasapalabraComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
