import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AccordionModule } from 'primeng/accordion';
import { MenuItem } from 'primeng/api'; 
import { InputTextModule } from 'primeng/inputtext';
import {ButtonModule} from 'primeng/button';
import { MenuModule } from 'primeng/menu';

@NgModule({
    imports: [ButtonModule, InputTextModule, MenuModule],
    exports:  [ButtonModule, InputTextModule, MenuModule]
  })
  
  export class PrimengModule { }
