import { Juego } from '../clases/juego'

export class JuegoTateti extends Juego {

    constructor(nombre?: string, gano?: boolean, jugador?: string) {
        super("Tateti", gano, jugador);
    }
    public verificar() {

        if (1 == 1) {
            this.gano = true;
        }
        if (this.gano) {
            return true;
        } else {
            return false;
        }
    }
}
