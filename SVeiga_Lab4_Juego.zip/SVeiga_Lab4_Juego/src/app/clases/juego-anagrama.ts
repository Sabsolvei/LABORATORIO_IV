export class JuegoAnagrama {
}
