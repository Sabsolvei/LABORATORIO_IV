
// var letraA = [
//     { "Guardar dinero como previsión para necesidades futuras": ["Ahorrar","Administrar"]  },
//     { "No murado, no cercado o no cerrado": ["Abierto", "Accesible"] }
// ]

// var letraB = [
//     { "Subvención para realizar estudios o investigaciones": ["Beca"] },
//     { "Herramienta formada por una barra metálica con la punta en espiral, para hacer agujeros en material duro": ["Broca", "Barrena"] }
// ]

// var letraC = [
//     { "Atribuir o echar la culpa a alguien":["Culpar", "Condenar", "Censurar"] },
//     { "Cosa apreciable que se adquiere a poca costa": ["Chollo"]  } //beneficio
// ]

// var letraD = [
//     { "Conjunto de dientes, muelas y colmillos que tiene en la boca una persona o un animal": ["Dentadura","Denticion"] },
//     { "Desterrar a alguien de algún lugar, por lo regular extranjero y confinarlo allí por razones políticas o como castigo": ["Deportarlo"] }
// ]
