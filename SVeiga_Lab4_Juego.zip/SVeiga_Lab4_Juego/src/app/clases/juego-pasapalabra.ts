import { Juego } from '../clases/juego'
import { } from '../clases/randomDefiniciones'
import { forEach } from '@angular/router/src/utils/collection';
export class JuegoPasapalabra extends Juego {

    public definicion: string;
    public letra: string;
    public letraAnterior: string;
    public tiempo;
    public palabraUsuario;
    public abecedario: Array<string>;
    public indexABC: number;
    public defActual;
    public definicionesDeLaPartida;
    public cantidadCorrectas: number;
    public cantidadIncorrectas: number;
    public cantidadPasapalabra: number;
    public modal: number;
    public buttonColor: string;
    public estadoPorLetra;
    public contadorAux = 0;

    letraA = [
        { id: 1, letra: 'A', definicion: "Guardar dinero como previsión para necesidades futuras", respuestas: ["Ahorrar", "Administrar"], correcto: 0 },
        { id: 2, letra: 'A', definicion: "No murado, no cercado o no cerrado", respuestas: ["Abierto", "Accesible"], correcto: 0 }
    ]

    letraB = [
        { id: 1, letra: 'c', definicion: "Subvención para realizar estudios o investigaciones", respuestas: ["Beca"], correcto: 0 },
        { id: 2, letra: 'C', definicion: "Herramienta formada por una barra metálica con la punta en espiral, para hacer agujeros en material duro", respuestas: ["Broca", "Barrena"], correcto: 0 }
    ]

    letraC = [
        { id: 1, letra: 'D', definicion: "Atribuir o echar la culpa a alguien", respuestas: ["Culpar", "Condenar", "Censurar"], correcto: 0 },
        { id: 2, letra: 'D', definicion: "Cosa apreciable que se adquiere a poca costa", respuestas: ["Chollo"], correcto: 0 } //beneficio
    ]

    letraD = [
        { id: 1, definicion: "Conjunto de dientes, muelas y colmillos que tiene en la boca una persona o un animal", respuestas: ["Dentadura", "Denticion"] },
        { id: 2, definicion: "Desterrar a alguien de algún lugar, por lo regular extranjero y confinarlo allí por razones políticas o como castigo", respuestas: ["Deportarlo"], correcto: 0 }
    ]

    letraE = [
        { id: 1, definicion: "Conjunto de dientes, muelas y colmillos que tiene en la boca una persona o un animal", respuestas: ["Dentadura", "Denticion"] },
        { id: 2, definicion: "Desterrar a alguien de algún lugar, por lo regular extranjero y confinarlo allí por razones políticas o como castigo", respuestas: ["Deportarlo"], correcto: 0 }
    ]

    letraF = [
        { id: 1, definicion: "Conjunto de dientes, muelas y colmillos que tiene en la boca una persona o un animal", respuestas: ["Dentadura", "Denticion"] },
        { id: 2, definicion: "Desterrar a alguien de algún lugar, por lo regular extranjero y confinarlo allí por razones políticas o como castigo", respuestas: ["Deportarlo"], correcto: 0 }
    ]

    letraG = [
        { id: 1, definicion: "Conjunto de dientes, muelas y colmillos que tiene en la boca una persona o un animal", respuestas: ["Dentadura", "Denticion"] },
        { id: 2, definicion: "Desterrar a alguien de algún lugar, por lo regular extranjero y confinarlo allí por razones políticas o como castigo", respuestas: ["Deportarlo"], correcto: 0 }
    ]

    letraH = [
        { id: 1, definicion: "Conjunto de dientes, muelas y colmillos que tiene en la boca una persona o un animal", respuestas: ["Dentadura", "Denticion"] },
        { id: 2, definicion: "Desterrar a alguien de algún lugar, por lo regular extranjero y confinarlo allí por razones políticas o como castigo", respuestas: ["Deportarlo"], correcto: 0 }
    ]

    letraI = [
        { id: 1, definicion: "Conjunto de dientes, muelas y colmillos que tiene en la boca una persona o un animal", respuestas: ["Dentadura", "Denticion"] },
        { id: 2, definicion: "Desterrar a alguien de algún lugar, por lo regular extranjero y confinarlo allí por razones políticas o como castigo", respuestas: ["Deportarlo"], correcto: 0 }
    ]

    letraJ = [
        { id: 1, definicion: "Conjunto de dientes, muelas y colmillos que tiene en la boca una persona o un animal", respuestas: ["Dentadura", "Denticion"] },
        { id: 2, definicion: "Desterrar a alguien de algún lugar, por lo regular extranjero y confinarlo allí por razones políticas o como castigo", respuestas: ["Deportarlo"], correcto: 0 }
    ]

    letraK = [
        { id: 1, definicion: "Conjunto de dientes, muelas y colmillos que tiene en la boca una persona o un animal", respuestas: ["Dentadura", "Denticion"] },
        { id: 2, definicion: "Desterrar a alguien de algún lugar, por lo regular extranjero y confinarlo allí por razones políticas o como castigo", respuestas: ["Deportarlo"], correcto: 0 }
    ]

    letraL = [
        { id: 1, definicion: "Conjunto de dientes, muelas y colmillos que tiene en la boca una persona o un animal", respuestas: ["Dentadura", "Denticion"] },
        { id: 2, definicion: "Desterrar a alguien de algún lugar, por lo regular extranjero y confinarlo allí por razones políticas o como castigo", respuestas: ["Deportarlo"], correcto: 0 }
    ]

    letraM = [
        { id: 1, definicion: "Atribuir o echar la culpa a alguien", respuestas: ["Culpar", "Condenar", "Censurar"], correcto: 0 },
        { id: 2, definicion: "Cosa apreciable que se adquiere a poca costa", respuestas: ["Chollo"], correcto: 0 } //beneficio
    ]

    letraN = [
        { id: 1, definicion: "Conjunto de dientes, muelas y colmillos que tiene en la boca una persona o un animal", respuestas: ["Dentadura", "Denticion"] },
        { id: 2, definicion: "Desterrar a alguien de algún lugar, por lo regular extranjero y confinarlo allí por razones políticas o como castigo", respuestas: ["Deportarlo"], correcto: 0 }
    ]

    letraO = [
        { id: 1, definicion: "Conjunto de dientes, muelas y colmillos que tiene en la boca una persona o un animal", respuestas: ["Dentadura", "Denticion"] },
        { id: 2, definicion: "Desterrar a alguien de algún lugar, por lo regular extranjero y confinarlo allí por razones políticas o como castigo", respuestas: ["Deportarlo"], correcto: 0 }
    ]

    letraP = [
        { id: 1, definicion: "Conjunto de dientes, muelas y colmillos que tiene en la boca una persona o un animal", respuestas: ["Dentadura", "Denticion"] },
        { id: 2, definicion: "Desterrar a alguien de algún lugar, por lo regular extranjero y confinarlo allí por razones políticas o como castigo", respuestas: ["Deportarlo"], correcto: 0 }
    ]

    letraQ = [
        { id: 1, definicion: "Conjunto de dientes, muelas y colmillos que tiene en la boca una persona o un animal", respuestas: ["Dentadura", "Denticion"] },
        { id: 2, definicion: "Desterrar a alguien de algún lugar, por lo regular extranjero y confinarlo allí por razones políticas o como castigo", respuestas: ["Deportarlo"], correcto: 0 }
    ]

    letraR = [
        { id: 1, definicion: "Conjunto de dientes, muelas y colmillos que tiene en la boca una persona o un animal", respuestas: ["Dentadura", "Denticion"] },
        { id: 2, definicion: "Desterrar a alguien de algún lugar, por lo regular extranjero y confinarlo allí por razones políticas o como castigo", respuestas: ["Deportarlo"], correcto: 0 }
    ]

    letraS = [
        { id: 1, definicion: "Conjunto de dientes, muelas y colmillos que tiene en la boca una persona o un animal", respuestas: ["Dentadura", "Denticion"] },
        { id: 2, definicion: "Desterrar a alguien de algún lugar, por lo regular extranjero y confinarlo allí por razones políticas o como castigo", respuestas: ["Deportarlo"], correcto: 0 }
    ]

    letraT = [
        { id: 1, definicion: "Conjunto de dientes, muelas y colmillos que tiene en la boca una persona o un animal", respuestas: ["Dentadura", "Denticion"] },
        { id: 2, definicion: "Desterrar a alguien de algún lugar, por lo regular extranjero y confinarlo allí por razones políticas o como castigo", respuestas: ["Deportarlo"], correcto: 0 }
    ]

    letraU = [
        { id: 1, definicion: "Conjunto de dientes, muelas y colmillos que tiene en la boca una persona o un animal", respuestas: ["Dentadura", "Denticion"] },
        { id: 2, definicion: "Desterrar a alguien de algún lugar, por lo regular extranjero y confinarlo allí por razones políticas o como castigo", respuestas: ["Deportarlo"], correcto: 0 }
    ]

    letraV = [
        { id: 1, definicion: "Conjunto de dientes, muelas y colmillos que tiene en la boca una persona o un animal", respuestas: ["Dentadura", "Denticion"] },
        { id: 2, definicion: "Desterrar a alguien de algún lugar, por lo regular extranjero y confinarlo allí por razones políticas o como castigo", respuestas: ["Deportarlo"], correcto: 0 }
    ]

    letraW = [
        { id: 1, definicion: "Conjunto de dientes, muelas y colmillos que tiene en la boca una persona o un animal", respuestas: ["Dentadura", "Denticion"] },
        { id: 2, definicion: "Desterrar a alguien de algún lugar, por lo regular extranjero y confinarlo allí por razones políticas o como castigo", respuestas: ["Deportarlo"], correcto: 0 }
    ]

    letraX = [
        { id: 1, definicion: "Conjunto de dientes, muelas y colmillos que tiene en la boca una persona o un animal", respuestas: ["Dentadura", "Denticion"] },
        { id: 2, definicion: "Desterrar a alguien de algún lugar, por lo regular extranjero y confinarlo allí por razones políticas o como castigo", respuestas: ["Deportarlo"], correcto: 0 }
    ]

    letraY = [
        { id: 1, definicion: "Conjunto de dientes, muelas y colmillos que tiene en la boca una persona o un animal", respuestas: ["Dentadura", "Denticion"] },
        { id: 2, definicion: "Desterrar a alguien de algún lugar, por lo regular extranjero y confinarlo allí por razones políticas o como castigo", respuestas: ["Deportarlo"], correcto: 0 }
    ]

    letraZ = [
        { id: 1, definicion: "Conjunto de dientes, muelas y colmillos que tiene en la boca una persona o un animal", respuestas: ["Dentadura", "Denticion"] },
        { id: 2, definicion: "Desterrar a alguien de algún lugar, por lo regular extranjero y confinarlo allí por razones políticas o como castigo", respuestas: ["Deportarlo"], correcto: 0 }
    ]

    constructor(nombre?: string, gano?: boolean, jugador?: string) {
        super("Pasapalabra", gano, jugador);

        this.estadoPorLetra = [
            { letra: 'A', correcto: 0 },
            { letra: 'B', correcto: 0 },
            { letra: 'C', correcto: 0 },
            { letra: 'D', correcto: 0 },
            { letra: 'E', correcto: 0 },
            { letra: 'F', correcto: 0 },
            { letra: 'G', correcto: 0 },
            { letra: 'H', correcto: 0 },
            { letra: 'I', correcto: 0 },
            { letra: 'J', correcto: 0 },
            { letra: 'K', correcto: 0 },
            { letra: 'L', correcto: 0 },
            { letra: 'M', correcto: 0 },
            { letra: 'N', correcto: 0 },
            { letra: 'O', correcto: 0 },
            { letra: 'P', correcto: 0 },
            { letra: 'Q', correcto: 0 },
            { letra: 'R', correcto: 0 },
            { letra: 'S', correcto: 0 },
            { letra: 'T', correcto: 0 },
            { letra: 'U', correcto: 0 },
            { letra: 'V', correcto: 0 },
            { letra: 'W', correcto: 0 },
            { letra: 'X', correcto: 0 },
            { letra: 'Y', correcto: 0 },
            { letra: 'Z', correcto: 0 }
        ];
        this.jugador = localStorage.getItem('usuario');
        this.definicionesDeLaPartida = [];
        this.abecedario = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'];
        this.indexABC = 0;
        this.letra = this.abecedario[this.indexABC];
        this.palabraUsuario = '';
        this.cantidadCorrectas = 0;
        this.cantidadIncorrectas = 0;
        this.cantidadPasapalabra = 0;
        this.modal = 1;
        this.buttonColor = 'rgb(34, 102, 148)';
    }

    public isEmpty(obj) {
        for (var key in obj) {
            if (obj.hasOwnProperty(key))
                return false;
        }
        return true;
    }

    public obtenerListaEstados(letra: string) {
        let estado: number;
        this.estadoPorLetra.forEach((element) => {
            if (element.letra == letra) {
                estado = element.correcto;
            }
        });
        return estado;
    }


    verificar() {
        return true;
    }

    public Verificar() {
        let verifico = 0;

        if (!this.isEmpty(this.palabraUsuario) || this.palabraUsuario == null) {
            // console.info("SE VERIFICA: Respuesta Ingresada: " + this.palabraUsuario + "// Respuestas posibles: " + this.defActual.respuestas);
            this.defActual.respuestas.forEach((element) => {
                if (this.palabraUsuario.toUpperCase() == element.toUpperCase()) {
                    verifico = 1;
                }
            });

            if (verifico == 1) {
                this.definicionesDeLaPartida.forEach((element) => {
                    if (element == this.defActual) {
                        element.correcto = 1;
                        element.letra = this.letra;
                        this.estadoPorLetra[this.indexABC].correcto = 1;
                        this.letraAnterior = this.letra;
                    }
                });

            }

            else {
                // console.info("NO ES CORRECTO :(");
                this.definicionesDeLaPartida.forEach((element) => {
                    if (element == this.defActual) {
                        element.correcto = 2;
                        element.letra = this.letra;
                        this.letraAnterior = this.letra;
                        this.estadoPorLetra[this.indexABC].correcto = 2;
                    }
                });
            }

        } else {
            console.info("esta vacio el campo");
            verifico = -1;
        }
        return verifico;
    }


    public pasapalabra() {

        console.info("PASAPALABRA :|" + this.contadorAux++);

        this.definicionesDeLaPartida.forEach((element) => {
            if (element == this.defActual) {
                element.correcto = 3;
                this.estadoPorLetra[this.indexABC].correcto = 3;
                this.letraAnterior = this.letra;
                console.log(this.indexABC + " --INDEX ABC");
                console.log(this.estadoPorLetra[this.indexABC].correcto + " --ESTADO PASAPALABRA");
            }
        });
        // this.avanzarABC();
        // this.generarDefinicionRandom();

    }

    public contabilizarResultado() {
        console.info("CONTABILIZO RESULTADO : ");
        this.definicionesDeLaPartida.forEach((element) => {
            if (element.correcto == 1) {
                this.cantidadCorrectas++;
            }
            else if (element.correcto == 2) {
                this.cantidadIncorrectas++;
            }
            else if (element.correcto == 3) {
                this.cantidadPasapalabra++;
                console.info(element.letra+"///"+ element.definicion +"///"+ element.correcto +"///");
                console.log("CANTIDAD PASAPALABRAS: " + this.cantidadPasapalabra);
            }
        });
        this.puntos = this.cantidadCorrectas;
    }

    obtengoEstado(letra: string): number | any {
        let estado;
        this.estadoPorLetra.forEach((element) => {
            if (element.letra == letra) {
                //console.info(element.letra + "\\" + letra);
                // console.info(element.correcto + ": CORRECTO");
                estado = element.correcto;
            }
        });
        return estado;
    }

    avanzarABC() {
        this.indexABC++;
        this.letra = this.abecedario[this.indexABC];
        // console.info("AVANZÓ A LETRA: ------------" + this.letra + "-----------------------");

    }


    generarDefinicionRandom() {

        let resp = [];
        console.info("LETRA: " + this.letra);
        let length: number;
        let aux;
        let nroRandom: number;

        switch (this.letra) {
            case 'A':
                aux = this.letraA;
                break;
            case 'B':
                aux = this.letraB;
                break;
            case 'C':
                aux = this.letraC;
                break;
            case 'D':
                aux = this.letraD;
                break;
            case 'E':
                aux = this.letraE;
                break;
            case 'F':
                aux = this.letraF;
                break;
            case 'G':
                aux = this.letraG;
                break;
            case 'H':
                aux = this.letraH;
                break;
            case 'I':
                aux = this.letraI;
                break;
            case 'J':
                aux = this.letraJ;
                break;
            case 'K':
                aux = this.letraK;
                break;
            case 'L':
                aux = this.letraL;
                break;
            case 'M':
                aux = this.letraM;
                break;
            case 'N':
                aux = this.letraN;
                break;
            case 'O':
                aux = this.letraO;
                break;
            case 'P':
                aux = this.letraP;
                break;
            case 'Q':
                aux = this.letraQ;
                break;
            case 'R':
                aux = this.letraR;
                break;
            case 'S':
                aux = this.letraS;
                break;
            case 'T':
                aux = this.letraT;
                break;
            case 'U':
                aux = this.letraU;
                break;
            case 'V':
                aux = this.letraV;
                break;
            case 'W':
                aux = this.letraW;
                break;
            case 'X':
                aux = this.letraX;
                break;
            case 'Y':
                aux = this.letraY;
                break;
            case 'Z':
                aux = this.letraZ;
                break;
            default:
                this.definicion = "letra aun no definida";
                break;
        }

        nroRandom = Math.floor((Math.random() * (aux.length)) + 0);
        this.definicion = aux[nroRandom].definicion;
        this.definicionesDeLaPartida.push(aux[nroRandom]);
        this.defActual = aux[nroRandom];
    }
}


    // aux = Object.keys(this.letraA[nroRandom]);
    // console.info("type aux: " + typeof aux);
    // console.info("AUX: " + aux);
    //this.definicion = (String)(aux);
    //console.info("QUE ES ESTO: " + this.letraA[nroRandom][aux]);
    // (this.letraA[nroRandom].respuestas).forEach((element) => {
    //     console.info("RESPUESTA" + element);
    //     this.respuestas.push((String)(element));
    // });
    // console.info("RESPUESTAS:" + this.respuestas);
