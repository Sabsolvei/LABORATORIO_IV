export class Jugador {
}
