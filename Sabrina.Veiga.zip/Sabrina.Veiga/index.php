<?php
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;


require_once './composer/vendor/autoload.php';
require_once './clases/AccesoDatos.php';
require_once './clases/mascotaApi.php';
require_once './clases/loginApi.php';
require_once './clases/MWparaAutentificar.php';
require_once './clases/MWparaCors.php';
require_once './clases/AutentificadorJWT.php';
// require_once './clases/PHPExcel.php';
// require_once './clases/archivoApi.php';

$config['displayErrorDetails'] = true;
$config['addContentLengthHeader'] = false;
header('Access-Control-Allow-Origin: *'); //'http://localhost:4200'
header("Access-Control-Allow-Headers: X-API-KEY, Origin, X-Requested-With, mimeType, Content-Type, Accept, Access-Control-Request-Method");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");
header("Allow: GET, POST, OPTIONS, PUT, DELETE");
// $method = $_SERVER['REQUEST_METHOD'];
// if($method == "OPTIONS") {
//     die();
// }

$app = new \Slim\App(["settings" => $config]);


$app->post('/ingreso/', \loginApi::class . ':login'); //->add(\MWparaCORS::class . ':HabilitarCORSTodos')


$app->group('/mascota', function () {
    $this->get('/', \mascotaApi::class . ':traerTodos');
    $this->get('/{nombre}', \mascotaApi::class . ':traerNombre');
    $this->post('/', \mascotaApi::class . ':CargarUno');
    $this->put('/', \mascotaApi::class . ':ModificarUno');
    $this->delete('/', \mascotaApi::class . ':BorrarUno');
    // $this->delete('/', \mascotaApi::class . ':BorrarUno');
    // $this->put('/uploadFoto', \mascotaApi::class . ':ModificarFoto');
});

  $app->run();
