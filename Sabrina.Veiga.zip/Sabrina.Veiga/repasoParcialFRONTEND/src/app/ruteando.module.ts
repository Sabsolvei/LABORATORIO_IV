import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
// importo del module principal
import { RouterModule, Routes, CanActivate } from '@angular/router';

import { MascotaComponent } from './componentes/mascota/mascota.component';
import { MostrarMascotaComponent } from './componentes/mostrar-mascota/mostrar-mascota.component';
import { LoginComponent } from './componentes/login/login.component';

// declaro donde quiero que se dirija
const MiRuteo = [
    { path: '', component: MascotaComponent },
    { path: 'Mascota', component: MascotaComponent },
    { path: 'MostrarMascota', component: MostrarMascotaComponent },
    { path: 'Login', component: LoginComponent },
    { path: '**', component: LoginComponent }
    // { path: 'error', component: ErrorComponent }
];

@NgModule({
    imports: [
        RouterModule.forRoot(MiRuteo)
    ],
    exports: [
        RouterModule
    ]
})
export class RuteandoModule { }
