import { Directive, ElementRef, HostListener, Input } from '@angular/core';

@Directive({
  selector: '[appHighlight]'
})
export class HighlightDirective {

  private _color;
  private _sexo: string;


  constructor(private el: ElementRef) {
  }

  ngOnInit() {
    if (this._sexo == 'F')
      this.el.nativeElement.style.backgroundColor = 'rgb(253, 204, 212)'; //rosa
    else if (this._sexo == 'M')
      this.el.nativeElement.style.backgroundColor = 'rgb(192, 225, 255)'; //celeste
    else
      this.el.nativeElement.style.backgroundColor = 'rgb(204, 204, 204)'; //gris
  }

  @Input() set appHighlight(sexo: string) {
    this._sexo = sexo;
  }


  // private _color;
  // private _condicion: boolean;


  // constructor(private el: ElementRef) {
  // }

  // ngOnInit() {
  //   if (this._condicion)
  //     this.el.nativeElement.style.backgroundColor = 'rgb(253, 204, 212)'; //rosa
  //   else
  //     this.el.nativeElement.style.backgroundColor = 'rgb(192, 225, 255)'; //celeste
  // }

  // @Input() set appHighlight(condition: boolean) {
  //   this._condicion = condition;
  // }

}



