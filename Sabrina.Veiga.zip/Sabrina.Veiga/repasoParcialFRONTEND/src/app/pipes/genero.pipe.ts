import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'genero'
})
export class GeneroPipe implements PipeTransform {

  transform(value: any, args?: any): any {
    if (value == 'M') {
      return "Masculino";
    } else if (value == 'F') {
      return "Femenino";
    } else if (value == 'ND') {
      return "No definido";
    }
  }
}
