import { GeneroPipe } from './genero.pipe';

describe('GeneroPipe', () => {
  it('create an instance', () => {
    const pipe = new GeneroPipe();
    expect(pipe).toBeTruthy();
  });
});
