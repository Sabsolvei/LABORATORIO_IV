export class UsuarioLogin {

    constructor(
        public mail: string,
        public password: string
    ) { }

}