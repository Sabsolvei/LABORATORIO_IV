export class mascota {

    public nombre;
    public tipo;
    public fechaDeNacimiento;
    public rutaDeFoto;
    public id;

    constructor(nombre, tipo, fechaDeNacimiento, rutaDeFoto) {
        this.nombre = nombre;
        this.tipo = tipo;
        this.rutaDeFoto = rutaDeFoto;
        this.fechaDeNacimiento = fechaDeNacimiento;
    }
}
