import { Injectable } from '@angular/core';
import { mascota } from '../clases/mascota';
import { MiHttpService } from './mi-http/mi-http.service';
import { Router, ActivatedRoute, Params } from '@angular/router';

@Injectable()
export class MascotaService {

  private _listamascotas;
  public filtrado: any;

  constructor(
    private _miHttp: MiHttpService,
    private _route: ActivatedRoute,
    private _router: Router
  ) { }


  public traerTodos(): Promise<Array<any>> {
    return this._miHttp.httpGetP("mascota/")
      .then(data => {
        return data;
      })
      .catch(err => {
        console.log(err);
        return null;
      });
  }

     public traermascota(nombre: any): Promise<Array<any>> {
    return this._miHttp.httpGet("mascota/", nombre)
      .then(data => {
        console.log("mascota SERVICE");
        console.log(data);
        return data;
      })
      .catch(err => {
        console.log(err);
        return null;
      });
  }


  public guardarmascota(mascota: mascota): any {
    return this._miHttp.httpPost("mascota/", mascota)
      .then(
        response => {
          return response;
        },
        error => {
          return error;
        })
      .catch(err => {
        console.log(err);
        return null;
      });
  }


  public editarmascota(mascota: mascota): any {
    return this._miHttp.httpPut("mascota/", mascota)
      .then(
        response => {
          return response;
        },
        error => {
          return error;
        }
      )
  }


  public eliminarmascota(id: number): any {
    return this._miHttp.httpDelete("mascota/", id)
      .then(
        response => {
          return response;
        },
        error => {
          return error;
        }
      )
  }


  public listarNombre(nombreMascota: any): Promise<Array<any>> {
    console.log("NOMBRE");
    console.log(nombreMascota);
    return this._miHttp.httpGetP("mascota/")
      .then(data => {
        this._listamascotas = data;
        console.log("lista mascota");
        console.log(this._listamascotas);
        this._listamascotas = this._listamascotas.filter(
          masc => masc.nombre == nombreMascota); return this._listamascotas
      })
      .catch(errror => {
        console.log("error");
        return this._listamascotas;
      });
  }


}



  // public guardarmascotaImg(mascota: mascota, file: any) {
  //   this._miHttp.httpPostConImagen$("mascota/", mascota, file)
  //     .subscribe(
  //       response => {
  //         if (response.status == 200) {
  //           //    console.log(<any>response);
  //           this._router.navigate(['../Login'], { relativeTo: this._route, queryParams: { mascota: mascota.mail } });
  //           //    queryParams: {mascota: mascota.email, clave: mascota.clave}, fragment: 'frag'});
  //         }
  //         else {
  //           console.log(response);
  //         }
  //       },
  //       error => {
  //         console.log(<any>error);
  //       }
  //     )
  // }

    // public traermascota(id: number): Promise<Array<any>> {
  //   return this._miHttp.httpGet("mascota/", id)
  //     .then(data => {
  //       console.log("mascota SERVICE");
  //       console.log(data);
  //       return data;
  //     })
  //     .catch(err => {
  //       console.log(err);
  //       return null;
  //     });
  // }

   // traertodos(ruta: string, filtro: string) {
  //   return this.archivosService.traerJugadores(ruta).then(data => {
  //     console.info("jugadores service", data);
  //     this.filtrado = data;
  //     let ganador: boolean;
  //     if (filtro == "ganadores") {
  //       ganador = true;
  //     }
  //     else {
  //       ganador = false;
  //     }

  //     this.filtrado = this.filtrado.filter(
  //       data => data.gano === ganador || filtro == "todos"); return this.filtrado
  //   }
  //   )
  //     .catch(errror => {
  //       console.log("error")
  //       return this.filtrado;
  //     });
  // }


