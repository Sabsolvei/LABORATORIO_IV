import { Injectable } from '@angular/core';
import { MiHttpService } from './mi-http/mi-http.service';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { UsuarioLogin } from '../clases/usuarioLogin';


import { Http, Response, RequestOptions, Headers } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/throw';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';


@Injectable()
export class LoginService {
  public errorMsj;
  constructor(
    private _miHttp: MiHttpService,
    private _route: ActivatedRoute,
    private _router: Router
  ) { }

  
  public verificarUsuario(usuarioLogin: UsuarioLogin): Promise<Array<any>> {

    return this._miHttp.httpPost("ingreso/", usuarioLogin)
      .then(data => {
        return data;
      })
      .catch(err => {
        return err;
      });
  }
}