import { log } from 'util';
import { Injectable } from '@angular/core';
// import { Angular2TokenService } from 'angular2-token';
import { Http, Response, RequestOptions, Headers } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/throw';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';
import * as $ from 'jquery';

@Injectable()
export class MiHttpService {
  public urlServer: String;
  public headers = new Headers({})

  constructor(public http: Http) {
    this.urlServer = "http://localhost:8080/repasoParcial/";
  }

  public httpGetP(url: string) {
    return this.http.get(this.urlServer + url)
      .toPromise()
      .then(this.extractData)
      .catch(this.handleError);
  }


   public httpGet(url: string, nombre: any) {
    let myHeaders = new Headers();
    myHeaders.append('Content-Type', 'application/json');
    let myParams = new URLSearchParams();
    myParams.append('nombre', nombre);
    let options = new RequestOptions({ headers: myHeaders, params: myParams });
    return this.http.get(this.urlServer + url, options)
      .toPromise()
      .then(this.extractData)
      .catch(this.handleError);
  }


  public httpPost(url: string, objeto: any) {
    let params = JSON.stringify(objeto);
    let headers = new Headers({ 'Content-type': 'application/json' });

    return this.http.post(this.urlServer + url, params, { headers: headers })
      .toPromise()
      .then(this.extractData)
      .catch(this.handleError);
  }

  public httpPut(url: string, objeto: any) {
    let params = JSON.stringify(objeto);
    let headers = new Headers({ 'Content-type': 'application/json' });
    return this.http.put(this.urlServer + url, params, { headers: headers })
      .toPromise()
      .then(this.extractData)
      .catch(this.handleError);
  }

  public httpDelete(url: string, id) {

    let body = JSON.stringify(
      {
        "id": id
      }
    );
    let headers = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions({ headers: headers, body: body });
    return this.http.delete(this.urlServer + url, options)
      .toPromise()
      .then(this.extractData)
      .catch(this.handleError);
  }

  private extractData(res: Response) {
    return res.json() || {};
  }

  private handleError(error: Response | any) {
    return Observable.throw(error || "Server error");
  }
}

  // public httpGet(url: string, id: number) {
  //   let myHeaders = new Headers();
  //   myHeaders.append('Content-Type', 'application/json');
  //   let myParams = new URLSearchParams();
  //   myParams.append('id', id.toString());
  //   let options = new RequestOptions({ headers: myHeaders, params: myParams });
  //   return this.http.get(this.urlServer + url, options)
  //     .toPromise()
  //     .then(this.extractData)
  //     .catch(this.handleError);
  // }

  // public httpPut$(url: string, objeto: any): Observable<Response> {
  //   let params = JSON.stringify(objeto);
  //   let headers = new Headers({ 'Content-type': 'application/json' });
  //   return this.http.put(this.urlServer + url, params, { headers: headers })
  //     .map(this.extractData)
  //     .catch(this.handleError);
  // }

    // public httpPost$(url: string, objeto: any): Observable<Response> {

  //   let params = JSON.stringify(objeto);

  //   let headers = new Headers({ 'Content-type': 'application/json' });

  //   return this.http.post(this.urlServer + url, params, { headers: headers })
  //     .map((this.extractData))
  //     .catch(this.handleError);
  // }

  // public httpDelete$(url: string, id): Observable<Response> {

  //   let body = JSON.stringify(
  //     {
  //       "id": id
  //     }
  //   );
  //   let headers = new Headers({ 'Content-Type': 'application/json' });
  //   let options = new RequestOptions({ headers: headers, body: body });
  //   return this.http.delete(this.urlServer + url, options)
  //     .map(this.extractData)
  //     .catch(this.handleError);
  // }

    // public httpGet$(url: string): Observable<Response> {
  //   return this.http.get(this.urlServer + url)
  //     .map((this.extractData))
  //     .catch(this.handleError);
  // }


  // public httpPostConImagen$(url: string, objeto: any, file: any): Observable<Response> {
  //   let objetoJSON = JSON.parse(JSON.stringify(objeto));
  //   console.log(objetoJSON);
  //   let formData = new FormData();
  //   formData.append('archivo', file);
  //   $.each(objetoJSON, function (key: any, value: any) {
  //     formData.append(key, value);
  //   });
  //   console.log(formData);

  //   let headers = new Headers({ 'mimeType': 'multipart/form-data' });
  //   headers.delete('Content-type');
  //   return this.http.post(this.urlServer + url, formData, { headers: headers })
  //     .map((res: Response) => res.json());
  // }