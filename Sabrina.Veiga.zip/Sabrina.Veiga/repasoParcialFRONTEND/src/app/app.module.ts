import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
// import { AgmCoreModule } from '@agm/core';

import { CommonModule } from '@angular/common';
import { NgModel, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppComponent } from './app.component';

import { HttpModule } from '@angular/http';

// import { AccordionModule } from 'ngx-bootstrap';
// agrego las clases para utilizar ruteo
import { RouterModule, Routes } from '@angular/router';
import { MiHttpService } from './servicios/mi-http/mi-http.service';
import { MascotaService } from './servicios/mascota.service';
import { MascotaComponent } from './componentes/mascota/mascota.component';
import { MostrarMascotaComponent } from './componentes/mostrar-mascota/mostrar-mascota.component';
import { RuteandoModule } from './ruteando.module';
import { HighlightDirective } from './directivas/highlight.directive';
import { GeneroPipe } from './pipes/genero.pipe';
import { LoginComponent } from './componentes/login/login.component';
import { LoginService } from './servicios/login.service';
import { FocusDirective } from './directivas/focus.directive';
import { BotonComponent } from './componentes/boton/boton.component';
import { BuscarComponent } from './componentes/buscar/buscar.component';


@NgModule({
  declarations: [
    AppComponent,
    MascotaComponent,
    MostrarMascotaComponent,
    HighlightDirective,
    GeneroPipe,
    LoginComponent,
    FocusDirective,
    BotonComponent,
    BuscarComponent
  
  ],
  entryComponents: [
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    FormsModule,
    ReactiveFormsModule,
    RuteandoModule,
    CommonModule,
    HttpModule,
    RouterModule
  
    // NgbModule.forRoot(MiRuteo),
    // importo el ruteo
    // RouterModule.forRoot(MiRuteo)
  ],
  providers: [ MiHttpService, MascotaService, LoginService ],
  bootstrap: [AppComponent]
})
export class AppModule { }
