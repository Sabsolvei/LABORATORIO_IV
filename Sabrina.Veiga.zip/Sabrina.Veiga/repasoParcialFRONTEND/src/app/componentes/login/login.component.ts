import { Component, OnInit, Directive, ElementRef, } from '@angular/core';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import { LoginService } from '../../servicios/login.service';
import { Subscription } from "rxjs";
import { TimerObservable } from "rxjs/observable/TimerObservable";
import { UsuarioLogin } from '../../clases/usuarioLogin';
// import { FocusDirective } from '../../focus.directive';

import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/throw';
import 'rxjs/add/operator/catch';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  private mail: string;
  private password: string;
  private error: any;
  constructor(
    private _route: ActivatedRoute,
    private _loginService: LoginService,
    private _router: Router

  ) {
    this.error = '';
  }


  ngOnInit() {
    // this._route.queryParams
    //   //.filter(params => params.order)
    //   .subscribe(params => {
    //     this.mail = params.usuario;

    //   });
  }

  Entrar() {
    let usuarioLogin: UsuarioLogin = new UsuarioLogin(this.mail , this.password);
    this._loginService.verificarUsuario(usuarioLogin)
          .then(response => {
            if (response['status'] == 200) {
              localStorage.setItem('token', response['token']);
              localStorage.setItem('perfil', response['perfil']);
              localStorage.setItem('mensaje', response['mensaje']);
              localStorage.setItem('usuario', response['this.usuario']);
              this._router.navigate(['../Persona'], { relativeTo: this._route });
            }
            else if (response['status'] == 409) {
              this.error = response['error'];
            }
            else {
              this.error = response['error'];
            }
          });
  }
}
