import { Component, OnInit, Input } from '@angular/core';
import { identifierModuleUrl } from '@angular/compiler';

@Component({
  selector: 'app-boton',
  templateUrl: './boton.component.html',
  styleUrls: ['./boton.component.css']
})
export class BotonComponent implements OnInit {
  public id;
  constructor() { }

  ngOnInit() {
  }

  @Input()
  set mascota(id: any) {
    //paso el objeto json a objeto typescript de clase mascota
    console.log("ID ");
    console.log(id);
    this.id = id;
  }

  // for (var key in mascota) {
  //   if (this._mascota.hasOwnProperty(key)) {
  //     this._mascota[key] = mascota[key];
  //   }
}
