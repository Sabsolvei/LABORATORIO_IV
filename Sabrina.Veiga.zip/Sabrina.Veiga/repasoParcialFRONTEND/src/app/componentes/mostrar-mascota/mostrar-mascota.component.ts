import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { mascota } from '../../clases/mascota';

@Component({
  selector: 'app-mostrar-mascota',
  templateUrl: './mostrar-mascota.component.html',
  styleUrls: ['./mostrar-mascota.component.css']
})
export class MostrarMascotaComponent implements OnInit {

  private _mascota: mascota;

  constructor() {
    this._mascota = new mascota('','','','');
  }
  ngOnInit() { }

  @Output() enviardato: EventEmitter<any> = new EventEmitter<any>();

  @Input()
  set mascota(mascota: any) {
    //paso el objeto json a objeto typescript de clase mascota
    console.log("mascota mostrar componente ");
    // console.log(mascota['id']);
    console.log(this._mascota);
    for (var key in mascota) {
      if (this._mascota.hasOwnProperty(key)) {
        this._mascota[key] = mascota[key];
      }
    }
    this._mascota.id = mascota['id']; 
    console.log("MOSTRAR mascota");
    console.log(this._mascota);
  }
  // get mascota(): any { return this._mascota; }


  enviar() {
    console.log("ENVIAR mascota");
    console.log(this._mascota);
    this.enviardato.emit(this._mascota);
  }
}
