import { Component, OnInit, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-buscar',
  templateUrl: './buscar.component.html',
  styleUrls: ['./buscar.component.css']
})
export class BuscarComponent implements OnInit {
  @Output() enviardato: EventEmitter<any> = new EventEmitter<any>();

  public busqueda;
  constructor() { }

  enviar() {
    console.log("ENVIAR mascota");
    console.log(this.busqueda);
    this.enviardato.emit(this.busqueda);
  }

  ngOnInit() {
  }

}
