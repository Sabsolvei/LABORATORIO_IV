import { Component, OnInit, SimpleChanges, Input, ChangeDetectorRef, ViewChild, Inject } from '@angular/core';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import {
  trigger,
  state,
  style,
  animate,
  transition
} from '@angular/animations';

import { DOCUMENT } from '@angular/platform-browser';
//para poder hacer las validaciones
import { Validators, FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { mascota } from '../../clases/mascota';
import { MascotaService } from '../../servicios/mascota.service';
import { forEach } from '@angular/router/src/utils/collection';
import * as $ from 'jquery';
import { Http, Response } from '@angular/http';

@Component({
  selector: 'app-mascota',
  templateUrl: './mascota.component.html',
  styleUrls: ['./mascota.component.css']
})





export class MascotaComponent implements OnInit {


  public idMascotaAux;



  public userForm: FormGroup;
  // private _nuevarutaDeFoto: String;
  // private dismatch = false;
  private _mascota: mascota;
  private _mascotasDelService;
  private activo = false;
  public mascota;

  public tipo = [];

  public fileFoto;
  public url;

  public idAux;
  public formActiveModificar: boolean;
  public formActiveAlta: boolean;
  private mascotaAux: any;


  constructor(
    @Inject(DOCUMENT) private document: Document,
    private _formBuilder: FormBuilder,
    private _mascotaService: MascotaService,
    private changeDetectorRef: ChangeDetectorRef,
    private _route: ActivatedRoute,
    public _router: Router

  ) {
    this.tipo = ['Perro', 'Gato'];
    this._mascota = new mascota('', '', '', '');
    this.formActiveModificar = false;
    this.formActiveAlta = false;
  }


  ngOnInit() {
    this.userForm = this._formBuilder.group({
      nombre: [''],
      tipo: [''],
      fechaDeNacimiento: [''],
      rutaDeFoto: [''],
      // nuevarutaDeFoto: ['', Validators.compose([Validators.required, Validators.minLength(6)])],
    });
    this.traermascotas();
  }

  // recibirNombre(e) {
  //   // console.log(e);
  //   this._mascotaService.listarNombre(e)
  //     .then(data => {
  //       console.log("MASCOTA");
  //       console.log(data);
  //       this.mascota = data;

  //     });
  //     console.log("MASCOTA RECIBIR NOMBRE");
  //     console.log(this.mascota);

  //   if (this.mascota) {
  //     // this.activo = true;
  //   }
  // }


  recibirNombre(e) {
    // console.log(e);
    this._mascotaService.traermascota(e)
      .then(data => {
        console.log(data);
        $.each(data, function (i, item) {
          console.log("item");
          console.log(item);
          console.log("item nombre");
          console.log(item['nombre']);
          console.log(e);
          if (item['nombre'].toString() === e.toString()) {
            console.log('A');
            this.mascotaAux = item;
          }
        });
        console.log("MASCOTA AUX");
        console.log(this.mascotaAux);
      });

    // this.activo = true;

    if (this.mascotaAux) {
      this.activo = true;
    }
  }



  seleccionarmascota(e) {
    if (e.target.checked) {
      this.idMascotaAux = e.target.value;
    }
  }

  bajamascota(id) {
    console.log("ID ELIMINAR " + id);
    this._mascotaService.eliminarmascota(id)
      .then(response => {
        console.log(response);
        if (response.status == 200) {
          console.log(response.respuesta);
          this.cerrarFormulario();
          this.traermascotas();
        }
      });
  }

  traermascotas() {
    this._mascotaService.traerTodos()
      .then(data => {
        this._mascotasDelService = data;
        console.log(this._mascotasDelService);
      });
  }




















  OnSubmit() {
    // if (this._nuevarutaDeFoto == this._mascota.rutaDeFoto) {
    if (this.userForm.valid) {
      if (this.formActiveAlta == true) {
        console.log("ALTA");
        this.altamascota();
      }
      else if (this.formActiveModificar == true) {
        console.log("MODIFICAR");
        this.modificarmascota();
      }
    }
    // } else { this.dismatch = true; }
  }




  altamascota() {
    console.log("alta mascota");
    this._mascotaService.guardarmascota(this._mascota)
      .then(response => {
        console.log(response);
        if (response.status == 200) {
          console.log(response.respuesta);
          this.cerrarFormulario();
          this.traermascotas();
        }
      });
  }


  modificarmascota() {
    this._mascotaService.editarmascota(this._mascota)
      .then(response => {
        console.log(response);
        if (response.status == 200) {
          console.log(response.respuesta);
          this.cerrarFormulario();
          this.traermascotas();
        }
      });
  }












  cargarmascota(e) {
    this.cerrarMostrarDatosComponent();
    if (e.target.checked) {
      setTimeout(() => {
        e.target.checked = false;
      }, 2000);

      this.idAux = e.target.value;
      this._mascotasDelService.forEach(mascota => {
        if (mascota.id == this.idAux) {
          this.formActiveModificar = true;
          this.cargarmascotaAlForm(mascota);

        }
      });
    }
  }

  cerrarMostrarDatosComponent() {
    $('#closeIcon').find('span').trigger('click');
  }

  recibirdato(e) {
    this.cerrarMostrarDatosComponent();
    this.idAux = e.id;
    this._mascotasDelService.forEach(mascota => {
      if (mascota.id == this.idAux) {
        this.formActiveModificar = true;
        this.cargarmascotaAlForm(mascota);
      }
    });
  }

  cargarmascotaAlForm(p: mascota) {
    this._mascota = new mascota(p.nombre, p.tipo, p.fechaDeNacimiento, p.rutaDeFoto);
    this._mascota.id = this.idAux;
    this.idAux = 0;
  }

  cerrarFormulario() {
    this.userForm.reset();
    this.formActiveAlta = false;
    this.formActiveModificar = false;
  }

  mostrarmascota(mascota) {
    this.cerrarFormulario();
    console.log("MOSTRAR mascota");
    console.log(mascota);
    this.mascotaAux = mascota;
    this.activo = true;
  }

  selectchange(e) {
    this._mascota.fechaDeNacimiento = e.target.value;
  }
}


  // actualizarDismatch() {

  //   if (this._nuevarutaDeFoto != this._mascota.rutaDeFoto && this._nuevarutaDeFoto != null) {
  //     this.dismatch = true;
  //   }
  //   else {
  //     this.dismatch = false;
  //   }
  // }


  // readUrl(event: any) {
  //   if (event.target.files && event.target.files[0]) {
  //     this.fileFoto = event.target.files[0];
  //     var reader = new FileReader();
  //     reader.onload = (event: any) => {
  //       this.url = event.target.result;
  //     }
  //     reader.readAsDataURL(event.target.files[0]);
  //     // console.log(event.target.files[0]);
  //   }
  // }