<?php
    require_once 'archivo.php';
    //require_once 'IApiUsable.php';

class archivoApi extends archivo
{


    public function cargarArchivo(Request $request, Response $response)
    {
        $arr = $request->getParsedBody();
        $titulo = $arr['titulo'];
        $container = $app->getContainer();
        $container['upload_directory'] = __DIR__ . '/uploads';
        $directory = $this->get('upload_directory');
        
        $uploadedFiles = $request->getUploadedFiles();
        
        // handle single input with single file upload
        $uploadedFile = $uploadedFiles['archivo'];
        if ($uploadedFile->getError() === UPLOAD_ERR_OK) {
            $filename = archivo::moveUploadedFile($directory, $uploadedFile, $titulo);
            $response->write('uploaded ' . $filename . '<br/>');
        }
    }

}
