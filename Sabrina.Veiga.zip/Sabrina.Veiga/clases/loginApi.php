<?php
require_once 'mascota.php';
// require_once 'archivo.php';

class loginApi//extends login
{
    public function login($request, $response, $args) 
    {
        // $token="";
        $ArrayDeParametros = $request->getParsedBody();
        $objDelaRespuesta= new stdclass();
        $mail=$ArrayDeParametros['mail'];
        $password= $ArrayDeParametros['password'];
        if(isset($mail) && isset($password) && $mail !="" && $password !="")
        {
                $rtaEsValido = persona::esValido($mail,$password);

                if($rtaEsValido->estado == 1)
                {
                    $persona= $rtaEsValido->persona;
                    // $objDelaRespuesta->token = AutentificadorJWT::CrearToken($persona);
                    $objDelaRespuesta->mensaje = $rtaEsValido->msj;
                    $objDelaRespuesta->status = 200;
                    return $response->withJson($objDelaRespuesta);
                }
                else
                {
                    $objDelaRespuesta->error = $rtaEsValido->msj;
                    $objDelaRespuesta->status = 409;
                    return $response->withJson($objDelaRespuesta);
                }
        } 
        else
        {
            $objDelaRespuesta->error = "Debe completar los campos mail y password";
            $objDelaRespuesta->status = 409;
            return $response->withJson($objDelaRespuesta);
        }
    } 
}