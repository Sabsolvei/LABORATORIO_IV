<?php
class mascota
{
    public $id;
    public $nombre;
    public $tipo;
    public $fechaDeNacimiento;
    public $rutaDeFoto;


//TRAER mascota
    public static function Traermascotas()
    {
        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
        $consulta =$objetoAccesoDato->RetornarConsulta("select * from mascotas");
        $consulta->execute();
        return $consulta->fetchAll(PDO::FETCH_CLASS, "mascota");
    }


    public static function Traermascota($id)
    {
        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
        $consulta =$objetoAccesoDato->RetornarConsulta("SELECT id, nombre, tipo, fechaDeNacimiento, rutaDeFoto 
													    FROM mascotas
													    WHERE id = '$id'");
        $consulta->execute();
        $mascotaBuscado= $consulta->fetchObject('mascota');
        return $mascotaBuscado;
    }

    public static function traerNombre($nombre)
    {
        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
        $consulta =$objetoAccesoDato->RetornarConsulta("SELECT id, nombre, tipo, fechaDeNacimiento, rutaDeFoto 
													    FROM mascotas
													    WHERE nombre = '$nombre'");
        $consulta->execute();
        $mascotaBuscado= $consulta->fetchObject('mascota');
        return $mascotaBuscado;
    }

    // public static function TraerUnmascotaPorMail($mail)
    // {
    //     $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
    //     $consulta =$objetoAccesoDato->RetornarConsulta("SELECT id, nombre, mail, sexo, password 
    //                                                     FROM mascota 
    //                                                     WHERE mail = '$mail'");
    //     $consulta->execute();
    //     $mascotaBuscado= $consulta->fetchObject('mascota');
    //     return $mascotaBuscado;
    // }




//INSERTAR MODIFICAR
    public function Guardarmascota()
    {
        if ($this->id>0) {
            $this->ModificarmascotaParametros();
        } else {
            $this->InsertarElmascotaParametros();
        }
    }

    // public function InsertarLoginDemascota($fechaLogin)
    // {
    //     $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
    //     $consulta =$objetoAccesoDato->RetornarConsulta("INSERT into ingresosmascota (fecha_Hora_Ingreso, id_mascota) values(:fechaHoraIngreso, :idmascota)");
    //     $consulta->bindValue(':fechaHoraIngreso', $fechaLogin, PDO::PARAM_STR);
    //     $consulta->bindValue(':idmascota', $this->id, PDO::PARAM_STR);
        
    //     $consulta->execute();
    //     return $objetoAccesoDato->RetornarUltimoIdInsertado();
    // }



//INSERTAR
    public function Insertarmascotaparametros()
    {
        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
        $consulta =$objetoAccesoDato->RetornarConsulta("INSERT into mascota  (nombre, tipo, sexo, password) values(:nombre,:tipo,:sexo,:password)");
        $consulta->bindValue(':nombre', $this->nombre, PDO::PARAM_STR);
        $consulta->bindValue(':tipo', $this->tipo, PDO::PARAM_STR);
        $consulta->bindValue(':password', $this->password, PDO::PARAM_STR);
        $consulta->bindValue(':sexo', $this->sexo, PDO::PARAM_STR);
        
        $consulta->execute();
        return $objetoAccesoDato->RetornarUltimoIdInsertado();
    }



//MODIFICAR
    public function ModificarmascotaParametros()
    {
        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();

        $consulta =$objetoAccesoDato->RetornarConsulta("UPDATE mascota 
                                                        SET nombre=:nombre,
                                                        tipo=:tipo,
                                                        sexo=:sexo,
                                                        password=:password                                                        
                                                        WHERE id=:id");
        $consulta->bindValue(':id', $this->id, PDO::PARAM_INT);
        $consulta->bindValue(':nombre', $this->nombre, PDO::PARAM_STR);
        $consulta->bindValue(':tipo', $this->tipo, PDO::PARAM_STR);
        $consulta->bindValue(':sexo', $this->sexo, PDO::PARAM_STR);
        $consulta->bindValue(':password', $this->password, PDO::PARAM_STR);
        
        return $consulta->execute();
    }


//BORRAR
    public function Borrarmascota($id)
    {
   
        // if (!empty($mascota) && (!is_null($mascota->foto))) {
        //        archivo::moverFotoABackup($mascota->foto, $persona->email, 'backupFotos/');
        // }
        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
        $consulta =$objetoAccesoDato->RetornarConsulta("DELETE 
                                                        FROM mascotas				
                                                        WHERE id=:id");
        $consulta->bindValue(':id', $this->id, PDO::PARAM_INT);
        $consulta->execute();
        return $consulta->rowCount();
    }

//VERIFICAR password MAIL ESTADO DE persona
    public static function esValido($mail, $password)
    {
        $resp = new stdClass();
        $persona= persona::TraerUnpersonaPorMail($mail);
        if ($persona != null) {
       //     $verify = password_verify($password, $persona->password);
       
            if ($password == $persona->password && $mail == $persona->mail) {
                    $resp->persona = $persona;
                    $resp->msj = "Bienvenida/o ". $persona->nombre . "!";
                    $resp->estado = 1;
            } 
            else 
            {
                $resp->msj = "Compruebe su email o password";
                $resp->estado = 0;
            }
        } 
        else 
        {
            $resp->msj = "Compruebe su email o password";
            $resp->estado = 0;
        }
        return $resp;
    }

}
