<?php
require_once 'mascota.php';
// require_once 'archivo.php';


class mascotaApi //extends mascota //implements IApiUsable
{
    public function traerUno($request, $response, $args)
    {
            $id = $args['id'];
            $mascota = mascota::Traermascota($id);
            return $response->withJson($mascota, 200);
    }

    public function traerNombre($request, $response, $args)
    {
            $id = $args['nombre'];
            $mascota = mascota::Traermascota($nombre);
            return $response->withJson($mascota, 200);
    }

 

    
    public function traerTodos($request, $response, $args)
    {
            $mascotas = mascota::Traermascotas();
            return $response->withJson($mascotas, 200);
    }


    public function CargarUno($request, $response, $args)
    {
        $ArrayDeParametros = $request->getParsedBody();
        $objDelaRespuesta= new stdclass();
        if (isset($ArrayDeParametros['nombre']) && isset($ArrayDeParametros['tipo']) && isset($ArrayDeParametros['fechaDeNacimiento']) && isset($ArrayDeParametros['password'])) {
            $nombre = $ArrayDeParametros['nombre'];
            $mail = $ArrayDeParametros['tipo'];
            $fechaDeNacimiento = $ArrayDeParametros['fechaDeNacimiento'];
            $password = $ArrayDeParametros['password'];
            //$password = password_hash($ArrayDeParametros['password'], PASSWORD_BCRYPT);
            // date_default_timezone_set('America/Argentina/Buenos_Aires');
            // $fechaCreacion = date("Y/m/d H:i:s");
            $mimascota = new mascota();
            $mimascota->nombre=$nombre;
            $mimascota->tipo=$tipo;
            $mimascota->fechaDeNacimiento=$fechaDeNacimiento;
            $mimascota->password=$password;
            // $ruta = $this->obtenerArchivo($request, $response, $tipo);
            // if (!is_null($ruta)) {
            //     if ($ruta != false) {
            //         $mimascota->foto = $ruta;
            //     }
            // } else {
            //     $objDelaRespuesta->error = "Error al intentar guardar archivo. ";
            //     return $response->withJson($objDelaRespuesta, 409);
            // }
        } else {
            $objDelaRespuesta->error = "Completar campos obligatorios";
            $objDelaRespuesta->status = 409;
            return $response->withJson($objDelaRespuesta);
        }
        
        $mimascota->Insertarmascotaparametros();
        $objDelaRespuesta->respuesta = "Alta exitosa.";
        $objDelaRespuesta->status = 200;
        return $response->withJson($objDelaRespuesta);
    }

    // public function obtenerArchivo($request, $response, $mail)
    // {
    //     $uploadedFiles = $request->getUploadedFiles();
        
    //     if (isset($uploadedFiles['archivo'])) {
    //         $uploadedFile = $uploadedFiles['archivo'];
    //         if ($uploadedFile->getError() === UPLOAD_ERR_OK) {
    //             $ruta = archivo::moveUploadedFile($uploadedFile, $mail, 'fotosmascotas/');
    //             return $ruta;
    //         } else {
    //             return null;
    //         }
    //     } else {
    //         return false;
    //     }
    // }


    public function ModificarUno($request, $response, $args)
    {
            $objDelaRespuesta= new stdclass();
            $mascotaAModificar = new mascota();
            $ArrayDeParametros = $request->getParsedBody();

        if (isset($ArrayDeParametros['id'])) {
            $mascotaAModificar = $mascotaAModificar->Traermascota($ArrayDeParametros['id']);
            if ($mascotaAModificar != null) {
                if (isset($ArrayDeParametros['nombre'])) {
                    $mascotaAModificar->nombre = $ArrayDeParametros['nombre'];
                }
                if (isset($ArrayDeParametros['tipo'])) {
                    $mascotaAModificar->tipo = $ArrayDeParametros['tipo'];
                }
                if (!empty($ArrayDeParametros['password'])) {
                    $mascotaAModificar->password = $ArrayDeParametros['password'];
                }
                if (isset($ArrayDeParametros['fechaDeNacimiento'])) {
                    $mascotaAModificar->fechaDeNacimiento = $ArrayDeParametros['fechaDeNacimiento'];
                }

                try {
                    $resultado = $mascotaAModificar->ModificarmascotaParametros();
                    $objDelaRespuesta->resultado=$resultado;
                    $objDelaRespuesta->status = 200;
                    $objDelaRespuesta->respuesta= "Modificación exitosa";
                } catch (PDOException $e) {
                    $objDelaRespuesta->error = "No fue modificado. Error: " . $e->getMessage();
                    $objDelaRespuesta->status = 409;
                    return $response->withJson($objDelaRespuesta);
                }
            } else {
                $objDelaRespuesta->error= "El id ingresado no existe.";
                $objDelaRespuesta->status = 409;
                return $response->withJson($objDelaRespuesta);
            }
        } else {
            $objDelaRespuesta->error= "Debe ingresar un id.";
            $objDelaRespuesta->status = 409;
            return $response->withJson($objDelaRespuesta);
        }

            return $response->withJson($objDelaRespuesta);
    }

    // public function ModificarFoto($request, $response, $args)
    // {
    //     if (!($putData = fopen("php://input", "r"))) {
    //         throw new \Exception("Can't get PUT data.");
    //     }

    //     $path = 'fotosmascotas/';
    // //$path = $this->fileHandler->createImagePath($recipeID, $fileName);
    //     $destination = fopen($path, 'w');
    //     stream_copy_to_stream($putData, $destination);
    //     $imageType = exif_imagetype($path);

    //     if (!($imageType == 3 || $imageType == 2 ||$imageType == 1)) { //png or jpeg or gif?
    //         unlink($path);
    //         echo $imageType;
    //         return $response->withStatus(400);
    //     }
    //     fclose($putData);
    //     fclose($destination);
    //     return $response->withStatus(201);
    // }




    public function BorrarUno($request, $response, $args)
    {
            $cantidadDeBorrados = 0;
            $ArrayDeParametros = $request->getParsedBody();
            $id=$ArrayDeParametros['id'];
            //$id = $args['id'];
            $mascota= new mascota();
            $mascota = mascota::Traermascota($id);
            if (!empty($mascota)) { //&& (!is_null($mascota->foto))
             //  archivo::moverFotoABackup($mascota->foto, $mascota->email, 'backupFotos/');
               $cantidadDeBorrados=$mascota->Borrarmascota($id);
            }
            

            $objDelaRespuesta= new stdclass();
        if ($cantidadDeBorrados>0) {
            $objDelaRespuesta->status = 200;
            $objDelaRespuesta->resultado="Los datos de ".$mascota->nombre." con id ".$mascota->id." fueron eliminados exitosamente";
        } else {
            $objDelaRespuesta->resultado="El id: ".$id." no existe.";
            $objDelaRespuesta->status = 409;
            return $response->withJson($objDelaRespuesta);
        }
            
            return $response->withJson($objDelaRespuesta);
    }
}
