<?php

class Archivo
{

    public static function moveUploadedFile($uploadedFile, $email, $destino)
    {
        if (!file_exists($destino)) {
            mkdir($destino);
        }
        
        $email = str_replace(" ", "_", $email);
        $extension = pathinfo($uploadedFile->getClientFilename(), PATHINFO_EXTENSION);
        $filename = trim($email) .'.'. $extension;

        $ruta = $destino . $filename;
        $uploadedFile->moveTo($ruta);
        
        return $ruta;
    }

    public static function moverFotoABackup($pathviejo, $email, $destino)
    {
        if (!file_exists($destino)) {
            mkdir($destino);
        }
        $extension = pathinfo($pathviejo, PATHINFO_EXTENSION);
        rename($pathviejo, "./ProductosBorrados/".trim($email)."-".date("Ymd_His").".".$extension);
    }

}
