define({ "api": [
  {
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "optional": false,
            "field": "varname1",
            "description": "<p>No type.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "varname2",
            "description": "<p>With type.</p>"
          }
        ]
      }
    },
    "type": "",
    "url": "",
    "version": "0.0.0",
    "filename": "./documentacion/apidoc/main.js",
    "group": "C__xampp_htdocs_PROGRAMACION3_Prog3_TP_Estacionamiento_Final_TP_Estacionamiento_SabrinaVeiga_documentacion_apidoc_main_js",
    "groupTitle": "C__xampp_htdocs_PROGRAMACION3_Prog3_TP_Estacionamiento_Final_TP_Estacionamiento_SabrinaVeiga_documentacion_apidoc_main_js",
    "name": ""
  },
  {
    "type": "any",
    "url": "/HabilitarCORS4200/",
    "title": "HabilitarCORS4200",
    "version": "0.1.0",
    "name": "HabilitarCORS4200",
    "group": "MIDDLEWARE",
    "description": "<p>Por medio de este MiddleWare habilito que se pueda acceder desde http://localhost:4200</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "ServerRequestInterface",
            "optional": false,
            "field": "request",
            "description": "<p>El objeto REQUEST.</p>"
          },
          {
            "group": "Parameter",
            "type": "ResponseInterface",
            "optional": false,
            "field": "response",
            "description": "<p>El objeto RESPONSE.</p>"
          },
          {
            "group": "Parameter",
            "type": "Callable",
            "optional": false,
            "field": "next",
            "description": "<p>The next middleware callable.</p>"
          }
        ]
      }
    },
    "examples": [
      {
        "title": "Como usarlo:",
        "content": "->add(\\verificador::class . ':HabilitarCORS4200')",
        "type": "json"
      }
    ],
    "filename": "./clases/MWparaCors.php",
    "groupTitle": "MIDDLEWARE"
  },
  {
    "type": "any",
    "url": "/HabilitarCORS8080/",
    "title": "HabilitarCORS8080",
    "version": "0.1.0",
    "name": "HabilitarCORS8080",
    "group": "MIDDLEWARE",
    "description": "<p>Por medio de este MiddleWare habilito que se pueda acceder desde http://localhost:8080</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "ServerRequestInterface",
            "optional": false,
            "field": "request",
            "description": "<p>El objeto REQUEST.</p>"
          },
          {
            "group": "Parameter",
            "type": "ResponseInterface",
            "optional": false,
            "field": "response",
            "description": "<p>El objeto RESPONSE.</p>"
          },
          {
            "group": "Parameter",
            "type": "Callable",
            "optional": false,
            "field": "next",
            "description": "<p>The next middleware callable.</p>"
          }
        ]
      }
    },
    "examples": [
      {
        "title": "Como usarlo:",
        "content": "->add(\\verificador::class . ':HabilitarCORS8080')",
        "type": "json"
      }
    ],
    "filename": "./clases/MWparaCors.php",
    "groupTitle": "MIDDLEWARE"
  },
  {
    "type": "any",
    "url": "/HabilitarCORSTodos/",
    "title": "HabilitarCORSTodos",
    "version": "0.1.0",
    "name": "HabilitarCORSTodos",
    "group": "MIDDLEWARE",
    "description": "<p>Por medio de este MiddleWare habilito que se pueda acceder desde cualquier servidor</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "ServerRequestInterface",
            "optional": false,
            "field": "request",
            "description": "<p>El objeto REQUEST.</p>"
          },
          {
            "group": "Parameter",
            "type": "ResponseInterface",
            "optional": false,
            "field": "response",
            "description": "<p>El objeto RESPONSE.</p>"
          },
          {
            "group": "Parameter",
            "type": "Callable",
            "optional": false,
            "field": "next",
            "description": "<p>The next middleware callable.</p>"
          }
        ]
      }
    },
    "examples": [
      {
        "title": "Como usarlo:",
        "content": "->add(\\verificador::class . ':HabilitarCORSTodos')",
        "type": "json"
      }
    ],
    "filename": "./clases/MWparaCors.php",
    "groupTitle": "MIDDLEWARE"
  },
  {
    "type": "any",
    "url": "/MWparaAutenticar/",
    "title": "Verificar Usuario",
    "version": "0.1.0",
    "name": "VerificarUsuario",
    "group": "MIDDLEWARE",
    "description": "<p>Por medio de este MiddleWare verifico las credeciales antes de ingresar al correspondiente metodo</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "ServerRequestInterface",
            "optional": false,
            "field": "request",
            "description": "<p>El objeto REQUEST.</p>"
          },
          {
            "group": "Parameter",
            "type": "ResponseInterface",
            "optional": false,
            "field": "response",
            "description": "<p>El objeto RESPONSE.</p>"
          },
          {
            "group": "Parameter",
            "type": "Callable",
            "optional": false,
            "field": "next",
            "description": "<p>The next middleware callable.</p>"
          }
        ]
      }
    },
    "examples": [
      {
        "title": "Como usarlo:",
        "content": "->add(\\MWparaAutenticar::class . ':VerificarUsuario')",
        "type": "json"
      }
    ],
    "filename": "./clases/MWparaAutentificar.php",
    "groupTitle": "MIDDLEWARE"
  },
  {
    "type": "get",
    "url": "/Lista",
    "title": "todos los empleados",
    "group": "empleado",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Object[]",
            "optional": false,
            "field": "lista",
            "description": "<p>de empleados</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "empleado.nombre",
            "description": "<p>Empleado nombre</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "empleado.apellido",
            "description": "<p>Empleado apellido</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "empleado.estado",
            "description": "<p>Empleado estado</p>"
          },
          {
            "group": "Success 200",
            "type": "Date",
            "optional": false,
            "field": "empleado.fechacreacion",
            "description": "<p>Fecha de creacion</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success",
          "content": "HTTP/1.1 200 OK\n[{\n  \"id\": 1,\n  \"nombre\": \"Juan\",\n  \"apellido\": \"Perez\",\n  \"email\": \"juanperez87@gmail.com\",\n  \"clave\": \"$2y$10$TQkVupeMO/giBJHwd8evquV3tqK6OOge/miLIxU.4a5UENA6ydz7G\",\n  \"turno\": \"Manana\",\n  \"perfil\": \"user\",\n  \"fechaCreacion\": \"2017/11/26 20:26:16\",\n  \"foto\": null,\n  \"estado\": \"Activo\"\n}]",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "List error",
          "content": "HTTP/1.1 500 Internal Server Error",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./index.php",
    "groupTitle": "empleado",
    "name": "GetLista"
  },
  {
    "type": "get",
    "url": "/Lista",
    "title": "todos los empleados",
    "group": "empleado",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "id",
            "optional": false,
            "field": "id",
            "description": "<p>empleado id</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Object[]",
            "optional": false,
            "field": "lista",
            "description": "<p>de empleados</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "empleado.nombre",
            "description": "<p>Empleado nombre</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "empleado.apellido",
            "description": "<p>Empleado apellido</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "empleado.estado",
            "description": "<p>Empleado estado</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "empleado.fechacreacion",
            "description": "<p>Fecha de creacion</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success",
          "content": "HTTP/1.1 200 OK\n[{\n  \"id\": 1,\n  \"nombre\": \"Juan\",\n  \"apellido\": \"Perez\",\n  \"email\": \"juanperez87@gmail.com\",\n  \"clave\": \"$2y$10$TQkVupeMO/giBJHwd8evquV3tqK6OOge/miLIxU.4a5UENA6ydz7G\",\n  \"turno\": \"Manana\",\n  \"perfil\": \"user\",\n  \"fechaCreacion\": \"2017/11/26 20:26:16\",\n  \"foto\": null,\n  \"estado\": \"Activo\"\n}]",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "List error",
          "content": "HTTP/1.1 500 Internal Server Error",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./index.php",
    "groupTitle": "empleado",
    "name": "GetLista"
  },
  {
    "type": "post",
    "url": "/empleado",
    "title": "Register a new task",
    "group": "empleado",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "nombre",
            "description": "<p>empleado nombre</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "apellido",
            "description": "<p>empleado apellido</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "email",
            "description": "<p>empleado email</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "clave",
            "description": "<p>empleado clave</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "turno",
            "description": "<p>empleado turno</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Input",
          "content": "{\n  \"nombre\": \"Juan\",\n  \"apellido\": \"Perez\",\n  \"email\": \"juanperez87@gmail.com\",\n  \"clave\": \"1234\",\n  \"turno\": \"Manana\"\n}",
          "type": "json"
        }
      ]
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "empleado.nombre",
            "description": "<p>Empleado nombre</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "empleado.apellido",
            "description": "<p>Empleado apellido</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "empleado.estado",
            "description": "<p>Empleado estado</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "empleado.fechacreacion",
            "description": "<p>Fecha de creacion</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success",
          "content": "HTTP/1.1 200 OK\n\"Se guardo el empleado\"",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "Register error",
          "content": "HTTP/1.1 500 Internal Server Error",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./index.php",
    "groupTitle": "empleado",
    "name": "PostEmpleado"
  }
] });
